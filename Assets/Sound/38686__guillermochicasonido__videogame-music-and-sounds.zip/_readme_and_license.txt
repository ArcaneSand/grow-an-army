Pack downloaded from Freesound
----------------------------------------

"Videogame Music and Sounds"

This Pack of sounds contains sounds by the following user:
 - guillermochicasonido ( https://freesound.org/people/guillermochicasonido/ )

You can find this pack online at: https://freesound.org/people/guillermochicasonido/packs/38686/


Licenses in this Pack (see below for individual sound licenses)
---------------------------------------------------------------

Attribution 4.0: https://creativecommons.org/licenses/by/4.0/


Sounds in this Pack
-------------------

  * 691655__guillermochicasonido__videogame-victory-combat-jingle.wav.wav
    * url: https://freesound.org/s/691655/
    * license: Attribution 4.0
  * 691654__guillermochicasonido__videogame-title-screen-music.wav.wav
    * url: https://freesound.org/s/691654/
    * license: Attribution 4.0
  * 691653__guillermochicasonido__videogame-starting-combat-jingle.wav.wav
    * url: https://freesound.org/s/691653/
    * license: Attribution 4.0
  * 691652__guillermochicasonido__videogame-music-loop.wav.wav
    * url: https://freesound.org/s/691652/
    * license: Attribution 4.0
  * 691651__guillermochicasonido__combat-music.wav.wav
    * url: https://freesound.org/s/691651/
    * license: Attribution 4.0
  * 688242__guillermochicasonido__menu-selection.wav.wav
    * url: https://freesound.org/s/688242/
    * license: Attribution 4.0
  * 688241__guillermochicasonido__menu-navigation.wav.wav
    * url: https://freesound.org/s/688241/
    * license: Attribution 4.0
  * 688238__guillermochicasonido__fire-ball-attack.wav.wav
    * url: https://freesound.org/s/688238/
    * license: Attribution 4.0
  * 667633__guillermochicasonido__teleportation-disappearing-and-appearing.wav.wav
    * url: https://freesound.org/s/667633/
    * license: Attribution 4.0


